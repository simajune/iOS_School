//
//import Foundation
//
//struct User {
//    let user: String
//    let photoID: String
//    
//    init(with Dic: [String: Any]) {
//        guard let user = Dic["user"] as? String else { return }
//        self.user = user
//        guard let photoID = Dic["photoID"] as? String else { return }
//        self.photoID = photoID
//        
//    }
//}

