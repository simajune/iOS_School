
import Foundation
import Firebase

class NetworkService {
  
  var mainDatabase:InstaDatabase?
  
  func loadData() {
    
  }
  
  init() {
    loadData()
  }
}


