//
//enum ViewcontollerType {
//    case main
//    case profile
//}
//
//import UIKit
//
//class TotalViewController: UIViewController {
//
//    let controllerType: ViewcontollerType!
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        // Do any additional setup after loading the view.
//    }
//
//
//}

