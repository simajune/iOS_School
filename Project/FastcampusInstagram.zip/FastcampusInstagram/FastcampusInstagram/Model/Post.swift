//
//import Foundation
//
//struct Post {
//    let user: String
//    let postDate: String
// 
//    init(with Dic: [String: Any]) {
//        guard let user = Dic["user"] as? String else { return }
//        self.user = user
//        guard let postDate = Dic["postDate"] as? String else { return }
//        self.postDate = postDate
//    }
//}

